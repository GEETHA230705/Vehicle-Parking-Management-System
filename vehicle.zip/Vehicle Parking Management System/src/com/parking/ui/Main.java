package com.parking.ui;

import java.util.Scanner;
import com.parking.service.*;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        VehicleService vs = new VehicleService();
        ParkingService ps = new ParkingService();
        ParkingSlotService ss = new ParkingSlotService();

        int ch;

        do {
            System.out.println("\n1 Add Vehicle");
            System.out.println("2 View Vehicles");
            System.out.println("3 Update Vehicle");
            System.out.println("4 Delete Vehicle");
            System.out.println("5 Start Parking");
            System.out.println("6 View Records");
            System.out.println("7 View Slots");
            System.out.println("8 Exit");
            System.out.print("Choose your option: ");

            ch = sc.nextInt();

            switch (ch) {

                case 1:
                    System.out.print("Enter ID: ");
                    int id = sc.nextInt();

                    System.out.print("Enter Vehicle Number: ");
                    String number = sc.next();

                    System.out.print("Enter Owner Name: ");
                    sc.nextLine(); // clear buffer
                    String owner = sc.nextLine();

                    vs.addVehicle(id, number, owner);
                    break;

                case 2:
                    vs.viewVehicles();
                    break;

                case 3:
                    System.out.print("Enter Vehicle ID: ");
                    int updateId = sc.nextInt();

                    System.out.print("Enter New Owner Name: ");
                    sc.nextLine(); // clear buffer
                    String newOwner = sc.nextLine();

                    vs.updateVehicle(updateId, newOwner);
                    break;

                case 4:
                    System.out.print("Enter Vehicle ID: ");
                    int deleteId = sc.nextInt();

                    vs.deleteVehicle(deleteId);
                    break;

                case 5:
                    System.out.print("Enter Record ID: ");
                    int recordId = sc.nextInt();

                    System.out.print("Enter Vehicle ID: ");
                    int vehicleId = sc.nextInt();

                    System.out.print("Enter Slot ID: ");
                    int slotId = sc.nextInt();

                    ps.parkVehicle(recordId, vehicleId, slotId);
                    break;

                case 6:
                    ps.viewRecords();
                    break;

                case 7:
                    ss.viewSlots();
                    break;

                case 8:
                    System.out.println("Exit");
                    break;

                default:
                    System.out.println("Invalid Choice ❌");
            }

        } while (ch != 8);

        sc.close();
    }
}