package com.parking.dao;

import java.sql.*;
import com.parking.util.DBConnection;

public class ParkingSlotDAO {

    public void viewSlots() {
        try {
            Connection conn = DBConnection.getConnection();
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM parking_slot");

            while (rs.next()) {
                System.out.println("Slot: " + rs.getInt(1) +
                        " Occupied: " + rs.getBoolean(2));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean isSlotAvailable(int slotId) {
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                    "SELECT occupied FROM parking_slot WHERE slot_id=?");

            ps.setInt(1, slotId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return !rs.getBoolean("occupied");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public void updateSlot(int slotId, boolean status) {
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                    "UPDATE parking_slot SET occupied=? WHERE slot_id=?");

            ps.setBoolean(1, status);
            ps.setInt(2, slotId);

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}