package com.parking.dao;

import java.sql.*;
import com.parking.util.DBConnection;

public class ParkingRecordDAO {

    public void addRecord(int recordId, int vehicleId, int slotId) {
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO parking_record VALUES(?,?,?)");

            ps.setInt(1, recordId);
            ps.setInt(2, vehicleId);
            ps.setInt(3, slotId);

            ps.executeUpdate();
            System.out.println("Record Added ✅");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void viewRecords() {
        try {
            Connection conn = DBConnection.getConnection();
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM parking_record");

            while (rs.next()) {
                System.out.println("Record: " + rs.getInt(1) +
                        " Vehicle: " + rs.getInt(2) +
                        " Slot: " + rs.getInt(3));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteRecord(int id) {
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                    "DELETE FROM parking_record WHERE record_id=?");

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}