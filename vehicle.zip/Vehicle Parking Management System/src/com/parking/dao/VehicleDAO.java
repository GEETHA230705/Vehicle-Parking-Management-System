package com.parking.dao;

import java.sql.*;
import com.parking.model.Vehicle;
import com.parking.util.DBConnection;

public class VehicleDAO {

    public void addVehicle(Vehicle v) {
        try {
            Connection conn = DBConnection.getConnection();
            String sql = "INSERT INTO vehicle VALUES(?,?,?)";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, v.getId());
            ps.setString(2, v.getNumber());
            ps.setString(3, v.getOwner());

            ps.executeUpdate();
            System.out.println("Vehicle Added ✅");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void viewVehicles() {
        try {
            Connection conn = DBConnection.getConnection();
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM vehicle");

            while (rs.next()) {
                System.out.println(rs.getInt(1) + " " +
                                   rs.getString(2) + " " +
                                   rs.getString(3));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateVehicle(int id, String owner) {
        try {
            Connection conn = DBConnection.getConnection();
            String sql = "UPDATE vehicle SET owner_name=? WHERE vehicle_id=?";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, owner);
            ps.setInt(2, id);

            ps.executeUpdate();
            System.out.println("Updated ✅");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteVehicle(int id) {
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement("DELETE FROM vehicle WHERE vehicle_id=?");

            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Deleted ✅");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}