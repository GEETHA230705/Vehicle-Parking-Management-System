package com.parking.service;

import com.parking.dao.ParkingSlotDAO;

public class ParkingSlotService {

    ParkingSlotDAO dao = new ParkingSlotDAO();

    public void viewSlots() {
        dao.viewSlots();
    }

    public boolean isAvailable(int slotId) {
        return dao.isSlotAvailable(slotId);
    }

    public void occupy(int slotId) {
        dao.updateSlot(slotId, true);
    }

    public void free(int slotId) {
        dao.updateSlot(slotId, false);
    }
}