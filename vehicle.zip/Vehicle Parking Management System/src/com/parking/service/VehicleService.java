package com.parking.service;

import com.parking.dao.VehicleDAO;
import com.parking.model.Vehicle;

public class VehicleService {

    VehicleDAO dao = new VehicleDAO();

    public void addVehicle(int id, String num, String owner) {
        dao.addVehicle(new Vehicle(id, num, owner));
    }

    public void viewVehicles() { dao.viewVehicles(); }

    public void updateVehicle(int id, String owner) {
        dao.updateVehicle(id, owner);
    }

    public void deleteVehicle(int id) {
        dao.deleteVehicle(id);
    }
}