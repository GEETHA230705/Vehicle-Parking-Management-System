package com.parking.service;

import com.parking.dao.ParkingRecordDAO;

public class ParkingService {

    ParkingRecordDAO recordDAO = new ParkingRecordDAO();
    ParkingSlotService slotService = new ParkingSlotService();

    public void parkVehicle(int recordId, int vehicleId, int slotId) {

        if (slotService.isAvailable(slotId)) {

            recordDAO.addRecord(recordId, vehicleId, slotId);
            slotService.occupy(slotId);

            System.out.println("Vehicle Parked 🚗");

        } else {
            System.out.println("Slot Occupied ❌");
        }
    }

    public void removeVehicle(int recordId, int slotId) {

        recordDAO.deleteRecord(recordId);
        slotService.free(slotId);

        System.out.println("Vehicle Removed 🚪");
    }

    public void viewRecords() {
        recordDAO.viewRecords();
    }
}