package com.parking.model;

public class ParkingRecord {

    private int recordId;
    private int vehicleId;
    private int slotId;

    public ParkingRecord(int recordId, int vehicleId, int slotId) {
        this.recordId = recordId;
        this.vehicleId = vehicleId;
        this.slotId = slotId;
    }

    public int getRecordId() { return recordId; }
    public int getVehicleId() { return vehicleId; }
    public int getSlotId() { return slotId; }
}