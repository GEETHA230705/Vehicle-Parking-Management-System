package com.parking.model;

public class ParkingSlot {

    private int slotId;
    private boolean occupied;

    public ParkingSlot(int slotId, boolean occupied) {
        this.slotId = slotId;
        this.occupied = occupied;
    }

    public int getSlotId() { return slotId; }
    public boolean isOccupied() { return occupied; }
}