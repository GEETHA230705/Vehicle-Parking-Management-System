package com.parking.model;

public class Vehicle {

    private int id;
    private String number;
    private String owner;

    public Vehicle(int id, String number, String owner) {
        this.id = id;
        this.number = number;
        this.owner = owner;
    }

    public int getId() { return id; }
    public String getNumber() { return number; }
    public String getOwner() { return owner; }
}